#include <stdint.h> //for uint32_t datatype
#include "led.h"    //for led functions
#include "MKL25Z4.h"

#define DELAY_COUNT 1000000
#define MASK(x) (1U << (x))


unsigned int myglobal[10] = {10,11,12,13,14,15,16,17,18,19};
/**
 * @brief delay function
 *
 * @param nof
 */
void delay(volatile uint32_t nof)
{
    while (nof != 0)
    {
        __asm("NOP");
        nof--;
    }
}

/**
 * @brief main function, bliks led colorsequences with dumb (busy) delay
 *
 * @return int
 */
int main(void)
{
    // unsigned int mylocal[10] = {0,1,2,3,4,5,6,7,8,9};
    // unsigned int i = 0;
    // int j = 0;

    initLed();

    // Enable Clock to Port E
    SIM->SCGC5 |= SIM_SCGC5_PORTE_MASK; 

    // Make pin GPIO
    PORTE->PCR[1] &= ~PORT_PCR_MUX_MASK;
    // Aktivere pin til GPIO og med Intern Pullup-resistor
    PORTE->PCR [1] |= PORT_PCR_MUX(1) | PORT_PCR_PE(1) | PORT_PCR_PS(1);
    // Clear switch bit to input
    PTE->PDDR &= ~MASK(1);

    while (1)   {
        if (PTE->PDIR & MASK(1))    {
            setLedColor(MAGENTA); 
        } else {
            setLedColor(BLUE);
        }
    }

    // while (1)
    // {   
    //     j = j+myglobal[i%10];
    //     myglobal[i%10] = i;
    //     setLedColor(MAGENTA);
    //     delay(DELAY_COUNT);
    //     setLedColor(BLUE);
    //     delay(DELAY_COUNT);
    // }

    return 0;
}