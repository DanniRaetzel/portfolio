#ifndef SYSTICK_H_
#define SYSTICK_H_

#include <stdint.h>

#define SYSTICK_CLOCK 3000000U // 3 MHz SysTick clock frequency

/**
 * @brief Function for setting up the SysTick timer
 * with a specified number of ticks
 * @param ticks: Number of ticks (for 1500ms at 3MHz clock)
 * @return int, 0 if OK, -1 if failure
 */
int initSystickTmr(unsigned int ticks);

#endif /* SYSTICK_H_ */
