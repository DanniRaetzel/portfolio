#include "sysTick.h"
#include "MKL25Z4.h"
#include "led.h"

#define BLUE_LED_PIN 1 // PTD1 for blå LED
static int led_state = 0; // Holder styr på LED-status (tændt/slukket)

// SysTick interrupt handler
void SysTick_Handler(void) {
    if (led_state) {
        setLedColor(BLACK); // Sluk LED
    } else {
        setLedColor(BLUE); // Tænd LED
    }
    led_state = !led_state; // Skift tilstand
}


int main(void) {
    unsigned int ticks = 1980000; // Ticks for 1500ms interrupt

    initLed(); // Initialiser blå LED

    // Initialiser SysTick timer med 1500ms interval
    if (initSystickTmr(ticks) != 0) {
        while (1) {
            // Fejl-håndtering: Bliv her, hvis initialisering fejler
        }
    }

    while (1) {
        // Alt arbejde håndteres i SysTick interrupt
    }
}
