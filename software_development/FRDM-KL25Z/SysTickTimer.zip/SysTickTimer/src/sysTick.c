#include "sysTick.h"
#include "MKL25Z4.h"

/**
 * @brief Function for setting up the SysTick timer
 * with 1500ms interrupt interval
 * @param ticks: Number of ticks (for 1500ms at 3MHz clock)
 * @return int, 0 if OK, -1 if failure
 */
int initSystickTmr(unsigned int ticks) {
    // Ensure ticks are within the 24-bit limit for SysTick
    if (ticks > 4500000) {
        return -1; // Invalid tick value
    }

    // Set reload value
    SysTick->LOAD = ticks - 1;

    // Clear the current value register
    SysTick->VAL = 0;

    // Configure SysTick: Enable interrupt and use alternative clock (3 MHz)
    SysTick->CTRL = SysTick_CTRL_TICKINT_Msk | // Enable interrupts
                    SysTick_CTRL_ENABLE_Msk;  // Enable SysTick timer

    return 0; // Success
}
