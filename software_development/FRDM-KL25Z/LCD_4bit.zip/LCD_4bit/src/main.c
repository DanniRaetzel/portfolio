
/**
 * @file    E3ISD1_lcd_4bit.c
 * @brief   Application entry point.
 */
#include <stdio.h>      //needed since we use sprintf
#include "LCD_4bit.h"   //LCD includes

/*
 * Application entry point.
 */
int main(void)
{
	/*i for counting*/
	int i=0;

	/* lcd text strings */
	unsigned char lcd1[20];
	unsigned char lcd2[20];

    Init_LCD();
    Clear_LCD();
    Print_LCD("Hello LCD");  

    Set_Cursor(0, 1);
    /* Enter an infinite loop, just incrementing a counter. */
    while(1)
    {
        i++ ;
        Delay(100);
        /* print text and i variable into string */
        sprintf(lcd2,"i : %05d",i);
        /* set cursor back to start of line*/
        Set_Cursor(0, 1);
        /* print the string */
        Print_LCD(lcd2);
    }
    return 0 ;
}