// sys_clock.h


#ifndef _sys_clock_h
#define _sys_clock_h

void pll_init(void);


#endif // _sys_clock_h