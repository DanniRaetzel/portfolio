// main.c

#include <stdint.h>
#include "MKL25Z4.h" 
#include "led.h"   
#include "sys_clock.h"

// Tilstandene for FSM
typedef enum {
    STATE_RED,
    STATE_GREEN,
    STATE_BLUE
} state_t;

state_t state = STATE_RED;       // Aktuel tilstand
unsigned int timeout = 300;      // Timeout for initial tilstand (i ms)

//systickhandler
void SysTick_Handler(void)
{
    static unsigned int counter = 0;
    counter++;

    if (counter >= timeout) {
        // Skift til næste tilstand når timeout er nået
        switch (state) {
            case STATE_RED:
                state = STATE_GREEN;
                timeout = 600;  // Timeout for grøn tilstand
                break;
            case STATE_GREEN:
                state = STATE_BLUE;
                timeout = 900;  // Timeout for blå tilstand
                break;
            case STATE_BLUE:
                state = STATE_RED;
                timeout = 300;  // Timeout for rød tilstand
                break;
        }
        counter = 0;    // Nulstil tælleren

        // Opdater LED baseret på den aktuelle tilstand
        switch (state) {
            case STATE_RED:
                setLedColor(RED);
                break;
            case STATE_GREEN:
                setLedColor(GREEN);
                break;
            case STATE_BLUE:
                setLedColor(BLUE);
                break;    
        }    
    }
}

int main(void) {
    pll_init();
    SysTick_Config(48000);  // Opsætning af systick med en periode på 1 ms
    initLed();                // Initialiser LED
    setLedColor(RED);         // Start med rød LED

    while (1) {
        // Hovedloop, alt håndteres i SysTick_Handler
    }

    return 0;
}