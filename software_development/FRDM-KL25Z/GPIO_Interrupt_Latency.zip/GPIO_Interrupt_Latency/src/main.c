
/**
 * @file    E3ISD1_lcd_4bit.c
 * @brief   Application entry point.
 */
#include "MKL25Z4.h"      //needed since we use sprintf
#include "led.h"
#include "key.h"
#include "sys_clock.h"

#define DBG_MAIN_POS	1
#define DBG_ISR_POS		0
#define SW_POS			6
#define MASK(x)			(1 << x)


/* module global variable for counting interrupts*/
volatile unsigned int count;


/**
 * Interrupt handler for PORTD
 * */
void PORTD_IRQHandler(void)
{
    //  
    // TODO set debug pin high
    //
	// Port B -> Port Set Output Register
	GPIOB->PSOR = (1 << DBG_ISR_POS);	// Sætter PTB0 høj

	NVIC_ClearPendingIRQ(PORTD_IRQn);
	if ((PORTD->ISFR & MASK(SW_POS)))
	{
		count++;
	}
	/* clear status flags */ 
	PORTD->ISFR = MASK(SW_POS);  // Ryd kun interrupt-flaget for PTD6

    //  
    // TODO clear debug pin
    //
	// Port B -> Port Clear Outpur Register
	GPIOB->PCOR = (1 << DBG_ISR_POS);	// Sætter PTB0 lav
}

/**
 * Init GPIO ports for debug
 * */
void init_debug_signals(void)
{
	/*enable clock for port D*/
	SIM->SCGC5 |= SIM_SCGC5_PORTB_MASK; 

	/* TODO 
	Set pins as GPIO */
	PORTB->PCR[DBG_MAIN_POS] = (1 << 8);	// Konfigurer PTB1 som GPIO (debug main)
	PORTB->PCR[DBG_ISR_POS] = (1 << 8);		// Konfigurer PTB0 som GPIO (debug ISR)

	/* TODO setup GPIO data direction for 
	DBG_MAIN_POS
	and
	DBG_ISR_POS
	 */

	// Sætter PTB1 (DBG_MAIN_POS) og PTB0 (DBG_ISR_POS) som output
	GPIOB->PDDR |= (1 << DBG_MAIN_POS) | (1 << DBG_ISR_POS);
}

/**
 * Init GPIO port for input switch w. pullup
 * */
void init_interrupt_pin(void)  
{
	/* enable clock for port D */
	SIM->SCGC5 |= SIM_SCGC5_PORTD_MASK;
	/* Select GPIO and enable pull-up resistors and
	 interrupts on falling edges for pin connected to switch */
	PORTD->PCR[SW_POS] = PORT_PCR_MUX(1) | PORT_PCR_PS_MASK | PORT_PCR_PE_MASK | PORT_PCR_IRQC(0x0a);
	/* Set port D switch bit to inputs */
	PTD->PDDR &= ~MASK(SW_POS);
	/* Enable Interrupts */
	NVIC_SetPriority(PORTD_IRQn, 128);
	NVIC_ClearPendingIRQ(PORTD_IRQn);
	NVIC_EnableIRQ(PORTD_IRQn);
}

/*
 * Application entry point.
 */
int main(void)
{
    /* set CPU clock to 48 MHz */
    pll_init();
	/* setup pin for interrpt */
	init_interrupt_pin();
    /* setup pins GPIO, to measure latency, using analog discovery*/
	init_debug_signals();

	/* allow interrupts*/
	__enable_irq();

	while (1)
	{
		/* TODO
		Toggle GPIO */
		// Port Toggle Output Register
		GPIOB->PTOR = (1 << DBG_MAIN_POS);
	}
    
    return 0;
}