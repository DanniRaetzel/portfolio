#include "MKL25Z4.h"

/**
 * @brief Initialize the PLL to generate a 48 MHz clock
 */
void pll_init(void) {
    // Enable the external reference clock (8 MHz crystal)
    MCG->C2 = MCG_C2_RANGE(1) | MCG_C2_EREFS0_MASK; // High-frequency range (4-8 MHz), external reference select
    // Select the external reference clock for the FLL/PLL
    MCG->C1 = MCG_C1_CLKS(2) | MCG_C1_FRDIV(3); // External clock source, divide reference clock by 256 (8 MHz / 256 = 31.25 kHz)
    // Wait for the oscillator to initialize
    while (!(MCG->S & MCG_S_OSCINIT0_MASK)) {}
    // Wait for the clock status bits to indicate we are using the external reference clock
    while ((MCG->S & MCG_S_IREFST_MASK)) {}
    // Wait for the external clock to be selected as the system clock source
    while ((MCG->S & MCG_S_CLKST_MASK) != MCG_S_CLKST(2)) {}
    // Now configure the PLL
    MCG->C5 = MCG_C5_PRDIV0(3); // Divide 8 MHz reference clock by 4 = 2 MHz (PRDIV0 = 3)
    // Set the VCO divider and enable the PLL
    MCG->C6 = MCG_C6_PLLS_MASK | MCG_C6_VDIV0(0); // Multiply by 24 = 48 MHz (VDIV0 = 0)
    // Wait for the PLL status bit to set
    while (!(MCG->S & MCG_S_PLLST_MASK)) {}
    // Wait for the PLL to lock
    while (!(MCG->S & MCG_S_LOCK0_MASK)) {}
    // Now switch to the PLL as the system clock source
    MCG->C1 &= ~MCG_C1_CLKS_MASK; // Select PLL output as the system clock
    while ((MCG->S & MCG_S_CLKST_MASK) != MCG_S_CLKST(3)) {} // Wait for PLL clock to be selected
}

