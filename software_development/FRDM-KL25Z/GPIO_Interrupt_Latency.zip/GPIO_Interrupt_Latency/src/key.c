#include "key.h"
#include "MKL25Z4.h"


/* Setup pins used for keys
    - enable clock to gpio module
    - setup PINs using PCR registers
    - setup PDDR bits to inputs 
*/
void keyInit(void)
{
    // Enable clock to gpio module D
    SIM->SCGC5 |= (1 << 12);   // Enable clock for Port D

    // Setup pinmultiplexer (PCR register) for PTD6 (KEY0_POS) as ALT1 (GPIO mode)
    PORTD->PCR[KEY0_POS] = (1 << 8);  // Set MUX bits to 001 for GPIO functionality

    // Set PTD6 (KEY0_POS) as input
    GPIOD->PDDR &= ~(1 << KEY0_POS);  // Set pin as input
}


int keyRead(void)
{
    // capture input from PINC 1 
    // read PDIR register
    int val;

    val = GPIOC->PDIR;
    // if no key pressed we get
    // xxxx....xxx1x
    // if key is pressed
    // xxxx....xxx0x

    // mask out all other bits, so we only get bit 1 in the register
    val = val & (1 << KEY0_POS);

    // if no key pressed we get
    // b0000....00010 in decimal = 2
    // if key pressed
    // b0000....00000

    return val;
}
