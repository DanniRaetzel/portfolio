#ifndef KEY_H
#define KEY_H

#define KEY_PORT PORTC
#define KEY_DDR DDRC
#define KEY_PIN PINC

#define KEY0_POS    12

void keyInit(void);
int keyRead(void);


#endif