#include <string.h>  // For strcpy

int a, b;
const char c = 123;
int d = 31;

int main(void)
{
    int e;
    char f[32];
    e = d + 7;
    a = e + 29999;
    strcpy(f, "Hello!");

    return 0;
}