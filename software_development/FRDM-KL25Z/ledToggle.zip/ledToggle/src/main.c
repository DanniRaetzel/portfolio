#include <stdint.h> //for uint32_t datatype
#include "led.h"    //for led functions
#include "MKL25Z4.h"

#define DELAY_COUNT 1000000
#define MASK(x) (1U << (x))


unsigned int myglobal[10] = {10,11,12,13,14,15,16,17,18,19};
/**
 * @brief delay function
 *
 * @param nof
 */
void delay(volatile uint32_t nof)
{
    while (nof != 0)
    {
        __asm("NOP");
        nof--;
    }
}

/**
 * @brief main function, bliks led colorsequences with dumb (busy) delay
 *
 * @return int
 */
int main(void)
{

    // Starter ved den første farve
    int color = 1;

    // Initialiserer LED'er
    initLed();

    // Enable Clock to Port E
    SIM->SCGC5 |= SIM_SCGC5_PORTE_MASK; 

    // Konfigurer PTE1 til GPIO og aktiver intern pull-up modstand
    PORTE->PCR[1] &= ~PORT_PCR_MUX_MASK;
    PORTE->PCR [1] |= PORT_PCR_MUX(1) | PORT_PCR_PE(1) | PORT_PCR_PS(1);

    // Sætter pin til input
    PTE->PDDR &= ~MASK(1);

    while(1)
    {
        // Tjek om knappen er trykket
        if (!(PTE->PDIR & MASK(1)))   // Hvis knappen er trykket (lavt signal)
        {
            delay(100000);  // delay
            color++;    // Skift til næste farve

            if (color > 8) color = 1;   // Reset til første farve, hvis over 8

            switch (color) {
		        case 1: setLedColor(BLACK); break;
		        case 2: setLedColor(WHITE); break;
		        case 3: setLedColor(RED); break;
		        case 4: setLedColor(GREEN); break;
		        case 5: setLedColor(BLUE); break;
		        case 6: setLedColor(YELLOW); break;
		        case 7: setLedColor(CYAN); break;
		        case 8: setLedColor(MAGENTA); break;
		        default: break;
            }

            while (!(PTE->PDIR & MASK(1))); // VEnt til knappen slippes

	    }

        delay(10000);   // Lille forsinkelse for at undgå kontinuerlig tryk
    }

    return 0;
}