#include "adc.h"
#include "pwm.h"
#include "led.h"

#define POT_CHANNEL 0 // Potentiometer på ADC kanal 0

int main(void) {
    unsigned short adcValue;
    unsigned int dutyCycle;

    // Initialiser ADC på kanal 0
    adcInit(POT_CHANNEL);

    // Initialiser PWM på PTD1 (blå LED) med 1 kHz frekvens
    pwmInit(1000);

    while (1) {
        // Læs analog værdi fra potentiometer
        adcValue = adcRead(POT_CHANNEL);

        // Konverter ADC-værdi (0-65535) til duty cycle (0-100%)
        dutyCycle = (adcValue * 100) / 65535;

        // Opdater PWM duty cycle
        pwmSetDutyCycle(dutyCycle);
    }
}