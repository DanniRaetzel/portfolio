#include "pwm.h"

/**
 * @brief Initialize the PWM module
 * @param frequency Desired frequency in Hz
 */
void pwmInit(unsigned int frequency) {
    // Aktivér clock for TPM0 og PORTD
    SIM->SCGC6 |= SIM_SCGC6_TPM0_MASK;
    SIM->SCGC5 |= SIM_SCGC5_PORTD_MASK;

    // Sæt PTD1 som TPM0_CH1 (ALT4)
    PORTD->PCR[1] = PORT_PCR_MUX(4); // ALT4 = TPM0_CH1

    // Sæt TPM clock-kilde til MCGFLLCLK (48 MHz)
    SIM->SOPT2 |= SIM_SOPT2_TPMSRC(1); // Clock source

    // Beregn MOD for ønsket frekvens
    unsigned int mod = (48000000 / frequency) - 1;
    TPM0->MOD = mod;

    // Konfigurer TPM0_CH1 til edge-aligned PWM, high-true pulses
    TPM0->CONTROLS[1].CnSC = TPM_CnSC_MSB_MASK | TPM_CnSC_ELSB_MASK;

    // Start TPM0 i up-counting mode
    TPM0->SC = TPM_SC_PS(0) | TPM_SC_CMOD(1); // Prescaler = 1
}


/**
 * @brief Set the duty cycle of the PWM signal
 * @param dutyCycle Duty cycle in percentage (0-100)
 */
void pwmSetDutyCycle(unsigned int dutyCycle) {
    if (dutyCycle > 100) {
        dutyCycle = 100; // Begræns til 100%
    }
    // Sæt channel value for TPM0_CH1
    TPM0->CONTROLS[1].CnV = (TPM0->MOD * dutyCycle) / 100;
}
