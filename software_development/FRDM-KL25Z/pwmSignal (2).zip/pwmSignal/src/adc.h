/**
 * @file adc.h
 * @brief Header file for the ADC driver for the KL25Z board.
 *
 * Provides function declarations for initializing and reading from the ADC.
 */

#ifndef ADC_H_
#define ADC_H_

#include "MKL25Z4.h"  // Access to ADC0 struct and registers

/**
 * @brief Initializes the ADC on a specified channel.
 *
 * Sets up the ADC in 16-bit mode with long sample time and low power settings.
 * The ADC is configured for software triggering and single-ended mode.
 *
 * @param channel Channel number 0-5, corresponding to pins A0-A5 on the KL25Z board.
 */
void adcInit(int channel);

/**
 * @brief Reads the ADC value from the specified channel in single-ended mode.
 *
 * This function blocks until the ADC conversion is complete and then returns the result.
 *
 * @param channel Channel number 0-5, corresponding to pins A0-A5 on the KL25Z board.
 * @return 16-bit ADC conversion result from the specified channel.
 */
unsigned short adcRead(int channel);

#endif /* ADC_H_ */
