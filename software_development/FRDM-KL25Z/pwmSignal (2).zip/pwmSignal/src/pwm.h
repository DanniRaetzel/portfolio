#ifndef PWM_H_
#define PWM_H_

#include "MKL25Z4.h"

/**
 * @brief Initialize the PWM module
 * @param frequency Desired frequency in Hz
 */
void pwmInit(unsigned int frequency);

/**
 * @brief Set the duty cycle of the PWM signal
 * @param dutyCycle Duty cycle in percentage (0-100)
 */
void pwmSetDutyCycle(unsigned int dutyCycle);

#endif /* PWM_H_ */
