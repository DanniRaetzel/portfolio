/**
 * @mainpage ADC Driver Documentation
 * 
 * @section intro_sec Introduction
 * 
 * This documentation provides an overview of the ADC driver module, including
 * initialization and reading functions for the ADC peripheral on the KL25Z board.
 * 
 * The ADC driver supports 16-bit resolution and basic error handling through an LED indicator.
 * 
 * @section usage_sec Usage
 * 
 * - Use `adcInit(channel)` to initialize the ADC on a specified channel.
 * - Use `adcRead(channel)` to read the ADC value from the selected channel.
 * 
 * This documentation also includes call graphs and dependency graphs for better visualization.
 */

/**
 * @file adc.c
 * @brief ADC driver implementation for KL25Z board with SEGGER RTT debugging support.
 *
 * This module provides functions to initialize and read from the ADC (Analog-to-Digital Converter)
 * on the KL25Z board. It is configured for 16-bit resolution, low power, and long sample time settings.
 * The module includes basic error handling by setting the LED to red if an invalid channel is selected.
 */

#include "adc.h"   /**< Header file for ADC driver, providing function declarations. */
#include "led.h"   /**< Header file for LED driver, used for error indication. */

/**
 * @brief Initializes ADC0 on the specified channel.
 *
 * This function configures ADC0 to operate in 16-bit resolution with low power
 * and long sample time settings. It validates the specified channel and enables
 * the necessary clocks for ADC0 and the ports. If an invalid channel is given,
 * the function will set the LED to red and enter an infinite loop to signal an error.
 *
 * @param channel Channel number 0-5, corresponding to pins A0-A5 on the KL25Z board.
 */
void adcInit(int channel)
{
    // Validate channel number and set ADC channel bits accordingly
    switch(channel) {
        case 0:
            channel = 0b01000;  /**< Binary representation for channel 0. */
            break;
        case 1:
            channel = 0b01001;  /**< Binary representation for channel 1. */
            break;
        case 2:
            channel = 0b01100;  /**< Binary representation for channel 2. */
            break;
        case 3:
            channel = 0b01101;  /**< Binary representation for channel 3. */
            break;
        case 4:
            channel = 0b01011;  /**< Binary representation for channel 4. */
            break;
        case 5:
            channel = 0b01111;  /**< Binary representation for channel 5. */
            break;
        default:
            setLedColor(RED);  /**< Set LED to red to indicate an error. */
            while(1);  /**< Infinite loop to halt the program for invalid channel. */
    }

    // Enable clock for ports B & C to allow ADC usage
    // This ensures that the pins associated with the ADC are powered and functional.
    // Port B is typically where ADC input pins are located on the KL25Z board.
    SIM->SCGC5 |= (SIM_SCGC5_PORTB_MASK | SIM_SCGC5_PORTC_MASK);

    // Enable clock for ADC0 to provide power to the converter
    // This is necessary to initialize and use ADC0 for conversions.
    SIM->SCGC6 |= SIM_SCGC6_ADC0_MASK;

    // Configure ADC0 settings for low power and 16-bit resolution
    ADC0->CFG1 = ADC_CFG1_ADLPC_MASK        /**< Low power configuration. */
               | ADC_CFG1_ADLSMP_MASK       /**< Long sample time for accuracy. */
               | ADC_CFG1_MODE(3)           /**< 16-bit resolution. */
               | ADC_CFG1_ADIV(0)           /**< Clock divider set to 1. */
               | ADC_CFG1_ADICLK(0);        /**< Bus clock input. */

    // Configure ADC0 for software trigger, disable compare and DMA, and set voltage reference
    ADC0->SC2 = ADC_SC2_ADTRG(0)           /**< Software trigger mode. */
              | ADC_SC2_ACFE(0)            /**< Disable compare function. */
              | ADC_SC2_DMAEN(0)           /**< Disable DMA. */
              | ADC_SC2_REFSEL(0);         /**< Voltage reference set to VREFH and VREFL. */

    // Setup port control register for analog functions on channel 0
    PORTB->PCR[0] &= ~PORT_PCR_MUX_MASK;   /**< Reset MUX bits for analog configuration. */
    PORTB->PCR[0] |= PORT_PCR_MUX(0);      /**< Set to analog mode. */
}

/**
 * @brief Reads the ADC value from the specified channel.
 *
 * This function initiates an ADC conversion on the specified channel and waits
 * for the conversion to complete before returning the result. If an invalid channel
 * is specified, the function sets the LED to red and enters an infinite loop.
 *
 * @param channel Channel number 0-5, corresponding to pins A0-A5 on the KL25Z board.
 * @return The 16-bit ADC conversion result from the specified channel.
 */
unsigned short adcRead(int channel)
{
    unsigned short res;  /**< Variable to store the ADC conversion result. */

    // Validate channel number and set ADC channel bits accordingly
    switch(channel) {
        case 0:
            channel = 0b01000;  /**< Binary representation for channel 0. */
            break;
        case 1:
            channel = 0b01001;  /**< Binary representation for channel 1. */
            break;
        case 2:
            channel = 0b01100;  /**< Binary representation for channel 2. */
            break;
        case 3:
            channel = 0b01101;  /**< Binary representation for channel 3. */
            break;
        case 4:
            channel = 0b01011;  /**< Binary representation for channel 4. */
            break;
        case 5:
            channel = 0b01111;  /**< Binary representation for channel 5. */
            break;
        default:
            setLedColor(RED);  /**< Set LED to red to indicate an error. */
            while(1);  /**< Infinite loop to halt the program for invalid channel. */
    }

    // Start the ADC conversion on the selected channel
    ADC0->SC1[0] = ADC_SC1_ADCH(channel)   /**< Set channel in ADCH field. */
                 | ADC_SC1_AIEN(0)         /**< Disable interrupt. */
                 | ADC_SC1_DIFF(0);        /**< Single-ended conversion. */

    // Wait for conversion to complete (polled implementation)
    // The loop checks the COCO (Conversion Complete) flag in SC1[0] register.
    // The loop exits when the conversion is finished, as indicated by COCO being set.
    while (!(ADC0->SC1[0] & ADC_SC1_COCO_MASK)) {
        // Waiting for the conversion completion flag (COCO) to be set
    }

    // Retrieve the conversion result
    // Once the COCO flag is set, the conversion result can be read from the R[0] register.
    res = (unsigned short)ADC0->R[0];

    return res;  /**< Return the 16-bit ADC conversion result. */
}
