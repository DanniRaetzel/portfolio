#ifndef FIFO_H
#define FIFO_H

#include <stdint.h> // For uint8_t

#define Q_MAX_SIZE 32

// Strukturen for køen
typedef struct {
    uint8_t Data[Q_MAX_SIZE];
    unsigned int Head;  // Index for det ældste element
    unsigned int Tail;  // Index for næste ledige plads
    unsigned int Size;  // Antal elementer i køen
} Q_T;

// Funktionsprototypera
void Q_Init(Q_T *q);
int Q_Enqueue(Q_T *q, uint8_t d);
uint8_t Q_Dequeue(Q_T *q);
int Q_Empty(Q_T *q);
int Q_Full(Q_T *q);
int Q_SIZE(Q_T *q);

#endif // FIFO_H
