#include "key.h"
#include "MKL25Z4.h"


/* Setup pins used for keys
    - enable clock to gpio module
    - setup PINs using PCR registers
    - setup PDDR bits to inputs 
*/

// void keyInit(void)
// {
//     // Enable clock to gpio module D
//     SIM->SCGC5 |= (1 << 12);   // Enable clock for Port D

//     // Setup pinmultiplexer (PCR register) for PTD6 (KEY0_POS) as ALT1 (GPIO mode)
//     PORTD->PCR[KEY0_POS] = (1 << 8);  // Set MUX bits to 001 for GPIO functionality
//     PORTD->PCR[KEY1_POS] = (1 << 8);  // Set MUX bits to 001 for GPIO functionality

//     // Set PTD6 (KEY0_POS) as input
//     GPIOD->PDDR &= ~(1 << KEY0_POS);  // Set pin as input
//     GPIOD->PDDR &= ~(1 << KEY1_POS);  // Set pin as input

// }

void init_keys(void) {
    // Aktiver clock for Port C og Port D
    SIM->SCGC5 |= SIM_SCGC5_PORTC_MASK | SIM_SCGC5_PORTD_MASK;

    // Konfigurer PTC3 (SW1) som GPIO med pull-up
    PORTC->PCR[SW1_POS] = PORT_PCR_MUX(1) | PORT_PCR_PE_MASK | PORT_PCR_PS_MASK;

    // Konfigurer PTD6 (SW3) som GPIO med pull-up
    PORTD->PCR[SW3_POS] = PORT_PCR_MUX(1) | PORT_PCR_PE_MASK | PORT_PCR_PS_MASK;

    // Sæt PTC3 og PTD6 som input
    GPIOC->PDDR &= ~(1 << SW1_POS);
    GPIOD->PDDR &= ~(1 << SW3_POS);
}


// int keyRead(void)
// {
//     // capture input from PINC 1 
//     // read PDIR register
//     int val;

//     val = GPIOC->PDIR;
//     // if no key pressed we get
//     // xxxx....xxx1x
//     // if key is pressed
//     // xxxx....xxx0x

//     // mask out all other bits, so we only get bit 1 in the register
//     val = val & (1 << KEY0_POS);

//     // if no key pressed we get
//     // b0000....00010 in decimal = 2
//     // if key pressed
//     // b0000....00000

//     return val;
// }
