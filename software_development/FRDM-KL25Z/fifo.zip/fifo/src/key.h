#ifndef KEY_H
#define KEY_H

#define KEY_PORT PORTC
#define KEY_DDR DDRC
#define KEY_PIN PINC

//#define KEY0_POS 7  // Knap til at fylde i køen
//#define KEY1_POS 8  // Knap til at fjerne fra køen

#define SW1_POS 3  // PTC3
#define SW3_POS 6  // PTD6

void keyInit(void);
int keyRead(void);


#endif