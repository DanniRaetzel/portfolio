#ifndef _sys_clock_h
#define _sys_clock_h

void pll_init(void);
void delay_ms(volatile uint32_t ms);

#endif // _sys_clock_h