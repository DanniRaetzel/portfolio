#include "MKL25Z4.h"
#include "interrupt.h"
#include "led.h"
#include "sys_clock.h"
#include "fifo.h"
#include "key.h"

// Global kø
Q_T queue;

int main(void) {
    /* Set CPU clock to 48 MHz */
    pll_init();

    /* Init peripherals */
    initLed();
    init_keys();
    Q_Init(&queue);


    /* Allow interrupts */
    __enable_irq();

    while (1) {
        // Fyld FIFO med SW1
        if (!(GPIOC->PDIR & (1 << SW1_POS))) {
            static uint8_t data = 0;
            if (!Q_Enqueue(&queue, data)) {
                setLedColor(RED);
                delay_ms(50);
                setLedColor(BLACK);
            } else {
                setLedColor(MAGENTA);
                delay_ms(50);
                setLedColor(BLACK);
                data++;
            }
        }

        // Tøm FIFO med SW3
        if (!(GPIOD->PDIR & (1 << SW3_POS))) {
            if (!Q_Empty(&queue)) {
                Q_Dequeue(&queue);
                setLedColor(YELLOW);
                delay_ms(50);
                setLedColor(BLACK);
            } else {
                setLedColor(BLUE);
                delay_ms(50);
                setLedColor(BLACK);
            }
        }

        // Opdater LED baseret på kø-status
        if (Q_Empty(&queue)) {
            setLedColor(BLUE);
        } else if (Q_Full(&queue)) {
            setLedColor(RED);
        } else {
            setLedColor(GREEN);
        }
    }
}
