#include "fifo.h"
#include "led.h"
#include "interrupt.h"

int Q_Enqueue(Q_T *q, uint8_t d) {
    uint32_t masking_state;
    // Hvis køen er fuld, returnér fejlkode
    if (!Q_Full(q)) {
        q->Data[q->Tail] = d;
        masking_state = __get_PRIMASK();  // Gem nuværende maskeringsstatus
        __disable_irq();  // Deaktiver interrupts
        q->Tail = (q->Tail + 1) % Q_MAX_SIZE;  // Opdater tail pointer
        q->Size++;  // Inkrementer størrelsen
        __set_PRIMASK(masking_state);  // Gendan maskeringsstatus
        return 1;  // Succes
    } else {
        return 0;  // Fejl
    }
}

uint8_t Q_Dequeue(Q_T *q) {
    uint32_t masking_state;
    uint8_t t = 0;
    // Hvis køen ikke er tom, fjern element
    if (!Q_Empty(q)) {
        t = q->Data[q->Head];
        masking_state = __get_PRIMASK();  // Gem nuværende maskeringsstatus
        __disable_irq();  // Deaktiver interrupts
        q->Head = (q->Head + 1) % Q_MAX_SIZE;  // Opdater head pointer
        q->Size--;  // Decrementer størrelsen
        __set_PRIMASK(masking_state);  // Gendan maskeringsstatus
    }
    return t;  // Returner fjernet element
}

void Q_Init(Q_T *q) {
    for (unsigned int i = 0; i < Q_MAX_SIZE; i++) {
        q->Data[i] = 0;  // Initialiser data til 0
    }
    q->Head = 0;
    q->Tail = 0;
    q->Size = 0;
}

int Q_Empty(Q_T *q) {
    return q->Size == 0;  // Returner sand, hvis køen er tom
}

int Q_Full(Q_T *q) {
    return q->Size == Q_MAX_SIZE;  // Returner sand, hvis køen er fuld
}

int Q_SIZE(Q_T *q) {
    return q->Size;  // Returner størrelsen på køen
}
