#include "interrupt.h"
#include "key.h"
#include "led.h"

extern Q_T queue;   // Global kø deklareret i main
volatile unsigned int count = 0;  // Global tæller


void init_interrupt_pin(void) {
    // Aktiver clock for Port C (til GPIO)
    SIM->SCGC5 |= SIM_SCGC5_PORTC_MASK;

    // Konfigurer PTC3 (SW1) som GPIO med pull-up og interrupt
    PORTC->PCR[SW1_POS] = PORT_PCR_MUX(1) | PORT_PCR_PE_MASK | PORT_PCR_PS_MASK | PORT_PCR_IRQC(0x0A);

    // Sæt PTC3 som input
    GPIOC->PDDR &= ~(1 << SW1_POS);

    // Konfigurer interrupt-prioritet og aktiver
    NVIC_SetPriority(PORTD_IRQn, 128);  // Lav prioritet (deles med PORTC)
    NVIC_ClearPendingIRQ(PORTD_IRQn);
    NVIC_EnableIRQ(PORTD_IRQn);
}



void PORTC_IRQHandler(void)
{
    uint32_t masking_state;

    // Tjek, om interruptet stammer fra SW_POS
    if (PORTC->ISFR & MASK(SW1_POS))
    {
        setLedColor(MAGENTA);  // Debug: Interrupt aktiveret
        // Beskyt operation mod preemption
        masking_state = __get_PRIMASK();
        __disable_irq();

        // Generer 4-8 dataelementer of forsøg at tilføje dem til køen
        for (int i = 0; i < 4 + (count % 5); i++) {
            if (!Q_Enqueue(&queue, count++)) {
                break;  // Afbryd, hvis køen er fuld
            }
        }

        __set_PRIMASK(masking_state); // Gendan interrupt-state
    }

    // Clear interrupt flag
    PORTC->ISFR = MASK(SW1_POS);
}
