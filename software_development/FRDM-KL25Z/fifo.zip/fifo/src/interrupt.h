#ifndef INTERRUPT_H
#define INTERRUPT_H

#include "MKL25Z4.h"
#include "fifo.h"

// Makroer
#define SW_POS 6
#define MASK(x) (1 << (x))

// Global variabel til interrupt-tæller
extern volatile unsigned int count;

// Funktionsprototyper
void init_interrupt_pin(void);
void PORTC_IRQHandler(void);

#endif // INTERRUPT_H
